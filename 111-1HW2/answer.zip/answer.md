﻿# 第2次作業-作業-HW2
>
>學號：109111130 
><br />
>姓名：林庭宇 
><br />
>作業撰寫時間：300 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2022/12/18
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x]說明內容
- [x]個人認為完成作業須具備觀念

## 說明程式與內容

開始寫說明，該說明需說明想法，
並於之後再對上述想法的每一部分將程式進一步進行展現，
若需引用程式區則使用下面方法，
若為.cs檔內程式除了於敘述中需註明檔案名稱外，
還需使用語法` ```csharp 程式碼 ``` `，
下段程式碼則為使用後結果：

```csharp
public partial class Bomb : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int[] ia_MIndex = new int[10] { 0, 7, 13, 28, 44, 62, 74, 75, 87, 90 };
            char[,] ca_Map = new char[10, 10];

            for (int i_Row = 0; i_Row < 10; i_Row++)
            {
                for (int i_Col = 0; i_Col < 10; i_Col++)
                {
                    ca_Map[i_Row, i_Col] = '0';
                }
            }

            for (int i_ct = 0; i_ct < 10; i_ct++)
            {
                int i_Row = ia_MIndex[i_ct] / 10;
                int i_Col = ia_MIndex[i_ct] % 10;

                if ((i_Row - 1) >= 0 && (i_Col - 1) >= 0)
                {
                    int i_Tmp = Convert.ToInt32(ca_Map[i_Row - 1, i_Col - 1]);
                    i_Tmp++;
                    ca_Map[i_Row - 1, i_Col - 1] = Convert.ToChar(i_Tmp);
                }
                if ((i_Row) >= 0 && (i_Col - 1) >= 0)
                {
                    int i_Tmp = Convert.ToInt32(ca_Map[i_Row, i_Col - 1]);
                    i_Tmp++;
                    ca_Map[i_Row, i_Col - 1] = Convert.ToChar(i_Tmp);
                }
                if ((i_Row - 1) >= 0 && (i_Col) >= 0)
                {
                    int i_Tmp = Convert.ToInt32(ca_Map[i_Row - 1, i_Col]);
                    i_Tmp++;
                    ca_Map[i_Row - 1, i_Col] = Convert.ToChar(i_Tmp);
                }
                if ((i_Row + 1) < 10 && (i_Col + 1) < 10)
                {
                    int i_Tmp = Convert.ToInt32(ca_Map[i_Row + 1, i_Col + 1]);
                    i_Tmp++;
                    ca_Map[i_Row + 1, i_Col + 1] = Convert.ToChar(i_Tmp);
                }
                if ((i_Row + 1) < 10 && (i_Col) >= 0)
                {
                    int i_Tmp = Convert.ToInt32(ca_Map[i_Row + 1, i_Col]);
                    i_Tmp++;
                    ca_Map[i_Row + 1, i_Col] = Convert.ToChar(i_Tmp);
                }
                if ((i_Row) >= 0 && (i_Col + 1) < 10)
                {
                    int i_Tmp = Convert.ToInt32(ca_Map[i_Row, i_Col + 1]);
                    i_Tmp++;
                    ca_Map[i_Row, i_Col + 1] = Convert.ToChar(i_Tmp);
                }
                if ((i_Row + 1) >= 0 && (i_Col - 1) >= 0)
                {
                    int i_Tmp = Convert.ToInt32(ca_Map[i_Row + 1, i_Col - 1]);
                    i_Tmp++;
                    ca_Map[i_Row + 1, i_Col - 1] = Convert.ToChar(i_Tmp);
                }
                if ((i_Row - 1) >= 0 && (i_Col + 1) < 10)
                {
                    int i_Tmp = Convert.ToInt32(ca_Map[i_Row - 1, i_Col + 1]);
                    i_Tmp++;
                    ca_Map[i_Row - 1, i_Col + 1] = Convert.ToChar(i_Tmp);
                }
            }
            for (int i_ct = 0; i_ct < 10; i_ct++)
            {
                int i_Row = ia_MIndex[i_ct] / 10;
                int i_Col = ia_MIndex[i_ct] % 10;
                ca_Map[i_Row, i_Col] = '*';
            }
            for (int i_Row = 0; i_Row < 10; i_Row++)
            {
                for (int i_Col = 0; i_Col < 10; i_Col++)
                {
                    Response.Write(ca_Map[i_Row, i_Col]);
                }
                Response.Write("<br>");
            }
        }
    }
```

若要於內文中標示部分.aspx檔，則使用以下標籤` ```html 程式碼 ``` `，
下段程式碼則為使用後結果：

```html
<%@ Page Language="C#" AutoEventWireup="true" ...>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<meta http-equiv="Content-Type" ...>
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
        </div>
    </form>
</body>
</html>
```


## 個人認為完成作業須具備觀念
這份作業我覺得比較困難,需要具備基本的程式概念以及上課專心聽老師講解,不然就只能多問問同學或者上網找資料和老師上課影片

